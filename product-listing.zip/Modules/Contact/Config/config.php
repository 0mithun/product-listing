<?php

return [
    'name' => 'Contact'
];
