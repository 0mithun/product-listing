<?php

namespace Modules\Contact\Repositories;

interface ContactInterface
{
    public function multipleDestroy(Object $request);
}
